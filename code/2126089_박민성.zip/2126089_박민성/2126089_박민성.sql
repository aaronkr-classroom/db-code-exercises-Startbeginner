CREATE TABLE class_code (
    code INT PRIMARY KEY,
    class VARCHAR(10),
    basis VARCHAR(20)
);

CREATE TABLE task_code (
    code INT PRIMARY KEY,
    task VARCHAR(30)
);

CREATE TABLE customer (
	cus_id VARCHAR(15) PRIMARY KEY,
	name VARCHAR(20) NOT NULL,
	cell CHAR(13) NOT NULL UNIQUE,
	addr VARCHAR(100),
	c_code NUMERIC(1) DEFAULT(3),
	FOREIGN KEY (c_code) REFERENCES class_code(code)
);

CREATE TABLE staff (
    staff_id NUMERIC(5) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday NUMERIC(6) NOT NULL,
    tel CHAR(12),
    salary NUMERIC(9),
    t_code NUMERIC(1) NOT NULL,
    hire_date CHAR(8) NOT NULL,
    FOREIGN KEY (t_code) REFERENCES task_code(code)
);

CREATE TABLE tour_bus (
    bus_id NUMERIC(2) PRIMARY KEY,
    seat NUMERIC(2),
    del_ysr NUMERIC(4)
);

CREATE TABLE driver (
    driver_id NUMERIC(5) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday CHAR(6) NOT NULL,
    cell CHAR(13) NOT NULL,
    pay NUMERIC(5) DEFAULT 15000,
    cont_date CHAR(8),
    cont_term CHAR(8)
);

CREATE TABLE tour (
    tour_num CHAR(8) PRIMARY KEY,
    departure VARCHAR(50) NOT NULL,
    arrival VARCHAR(50) NOT NULL,
    program VARCHAR(100),
    start_dt DATE NOT NULL,
    end_dt DATE NOT NULL,
    min_num NUMERIC(2),
    max_num NUMERIC(2),
    expense NUMERIC(7) NOT NULL,
    deposit NUMERIC(6),
    dept_yn CHAR(1) DEFAULT 'N',
    staff_id NUMERIC(5),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);

CREATE TABLE reserve (
    cus_id VARCHAR(15),
    tour_num CHAR(8),
    res_date CHAR(8) DEFAULT TO_CHAR(CURRENT_DATE, 'YYYYMMDD'),
    dep_yn CHAR(1) DEFAULT 'N',
    exp_yn CHAR(1) DEFAULT 'N',
    PRIMARY KEY (cus_id, tour_num),
    FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

CREATE TABLE assign_driver (
    tour_num CHAR(8),
    driver_id NUMERIC(5),
    work_hour NUMERIC(3),
    PRIMARY KEY (tour_num, driver_id),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

CREATE TABLE assign_bus (
    tour_num CHAR(8),
    bus_id NUMERIC(2),
    PRIMARY KEY (tour_num, bus_id),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (bus_id) REFERENCES tour_bus(bus_id)
);

CREATE INDEX tour_arrival_idx
ON tour (arrival);

CREATE INDEX driver_name_idx
ON driver (name);

-- 1. 고객등급코드
INSERT INTO class_code VALUES (1, '최우수', '최우수 고객');
INSERT INTO class_code VALUES (2, '우수', '우수 고객');
INSERT INTO class_code VALUES (3, '일반', '일반 고객');

SELECT * FROM class_code;

-- 2. 직원업무코드
INSERT INTO task_code VALUES (1, '여행상품관리');
INSERT INTO task_code VALUES (2, '예약관리');
INSERT INTO task_code VALUES (3, '관광버스배차관리');
INSERT INTO task_code VALUES (4, '직원관리');
INSERT INTO task_code VALUES (5, '고객관리');

SELECT * FROM task_code;

-- 3. 고객
INSERT INTO customer VALUES ('001','김철수','010-1111-1111','서울시 강남구',1);
INSERT INTO customer VALUES ('002','박영희','010-2222-2222','서울시 송파구',2);
INSERT INTO customer VALUES ('003','최수미','010-3333-3333','경기도 수원시',3);
INSERT INTO customer VALUES ('004','정민호','010-4444-4444','인천시 연수구',3);
INSERT INTO customer VALUES ('005','하지훈','010-5555-5555','대전시 서구',2);

SELECT * FROM customer;

-- 4. 직원
INSERT INTO staff VALUES (1001,'홍길동',900101,'02-1111-1111',3500000,1,'20200101');
INSERT INTO staff VALUES (1002,'김유나',920315,'02-2222-2222',3200000,2,'20210215');
INSERT INTO staff VALUES (1003,'이민호',890728,'02-3333-3333',4000000,3,'20190310');
INSERT INTO staff VALUES (1004,'박지성',850112,'02-4444-4444',4500000,4,'20180520');
INSERT INTO staff VALUES (1005,'최수정',950501,'02-5555-5555',3000000,5,'20230401');

SELECT * FROM staff;

-- 5. 관광버스
INSERT INTO tour_bus VALUES (1, 45, 2020);
INSERT INTO tour_bus VALUES (2, 40, 2019);
INSERT INTO tour_bus VALUES (3, 35, 2018);
INSERT INTO tour_bus VALUES (4, 50, 2021);
INSERT INTO tour_bus VALUES (5, 28, 2022);

SELECT * FROM tour_bus;

-- 6. 운전기사
INSERT INTO driver VALUES (20001,'김기사','800101','010-7777-1111',15000,'20230101','00000012');
INSERT INTO driver VALUES (20002,'이기사','820202','010-7777-2222',16000,'20230201','00000024');
INSERT INTO driver VALUES (20003,'박기사','850303','010-7777-3333',17000,'20230301','00000036');
INSERT INTO driver VALUES (20004,'최기사','870404','010-7777-4444',18000,'20230401','00000048');
INSERT INTO driver VALUES (20005,'정기사','900505','010-7777-5555',19000,'20230501','00000060');

SELECT * FROM driver;

-- 7. 여행상품
INSERT INTO tour VALUES
('TOUR0001','경기','부산','해운대 관광','2025-07-01','2025-07-03',10,40,300000,100000,'N',1001);

INSERT INTO tour VALUES
('TOUR0002','서울','제주','제주도 2박3일','2025-08-01','2025-08-03',15,45,500000,200000,'N',1002);

INSERT INTO tour VALUES
('TOUR0003','대전','경주','역사문화 탐방','2025-09-10','2025-09-12',10,35,250000,80000,'N',1003);

INSERT INTO tour VALUES
('TOUR0004','광주','여수','여수 바다 여행','2025-10-05','2025-10-07',12,50,350000,120000,'N',1004);

INSERT INTO tour VALUES
('TOUR0005','인천','강릉','동해안 여행','2025-11-01','2025-11-02',8,28,200000,50000,'N',1005);

SELECT * FROM tour;

-- 8. 예약
INSERT INTO reserve VALUES ('001','TOUR0001','20250601','Y','N');
INSERT INTO reserve VALUES ('002','TOUR0002','20250602','Y','Y');
INSERT INTO reserve VALUES ('003','TOUR0003','20250603','N','N');
INSERT INTO reserve VALUES ('004','TOUR0004','20250604','Y','N');
INSERT INTO reserve VALUES ('005','TOUR0005','20250605','N','N');

SELECT * FROM reserve;

-- 9. 기사배정
INSERT INTO assign_driver VALUES ('TOUR0001',20001,24);
INSERT INTO assign_driver VALUES ('TOUR0002',20002,30);
INSERT INTO assign_driver VALUES ('TOUR0003',20003,18);
INSERT INTO assign_driver VALUES ('TOUR0004',20004,20);
INSERT INTO assign_driver VALUES ('TOUR0005',20005,12);

SELECT * FROM assign_driver;

-- 10. 차량배정
INSERT INTO assign_bus VALUES ('TOUR0001',1);
INSERT INTO assign_bus VALUES ('TOUR0002',2);
INSERT INTO assign_bus VALUES ('TOUR0003',3);
INSERT INTO assign_bus VALUES ('TOUR0004',4);
INSERT INTO assign_bus VALUES ('TOUR0005',5);

SELECT * FROM assign_bus;

-- 1. 고객 등급 검색
SELECT name, c_code FROM customer WHERE cus_id = '003';

-- 2. 직원 담당업무 검색
SELECT name, t_code FROM staff WHERE staff_id = '1005';

-- 3. 여행상품 예약 고객 검색(JOIN 사용)
SELECT c.name, r.res_date, r.dep_yn
FROM customer c
JOIN reserve r
ON c.cus_id = r.cus_id
WHERE r.tour_num = 'TOUR0003';

-- 4. 여행상품 배정 운전기사 검색(JOIN 사용)
SELECT t.departure,
       d.name,
       d.cell
FROM tour t
JOIN assign_driver ad
    ON t.tour_num = ad.tour_num
JOIN driver d
    ON ad.driver_id = d.driver_id
WHERE t.tour_num = 'TOUR0005';

-- 5. 신규 고객 등록
INSERT INTO customer (cus_id, name, cell)
VALUES ('006', '박민성', '010-6666-6666');

SELECT * FROM customer;

-- 6. 직원 급여 수정
UPDATE staff
SET salary = salary + 200000
WHERE staff_id = 1004;

SELECT salary FROM staff WHERE staff_id = 1004;

-- 7. 예약 정보 삭제
DELETE FROM reserve
WHERE cus_id = '001'
  AND tour_num = 'TOUR0001';

SELECT * FROM reserve;

-- 마지막으로 테이블 삭제
DROP TABLE assign_bus;
DROP TABLE assign_driver;
DROP TABLE reserve;
DROP TABLE tour;
DROP TABLE driver;
DROP TABLE tour_bus;
DROP TABLE staff;
DROP TABLE customer;
DROP TABLE task_code;
DROP TABLE class_code;